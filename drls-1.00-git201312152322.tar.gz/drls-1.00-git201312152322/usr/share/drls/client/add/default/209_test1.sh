echo "20 -test addclient - default"
