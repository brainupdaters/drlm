echo "12 -test addclient - default"
