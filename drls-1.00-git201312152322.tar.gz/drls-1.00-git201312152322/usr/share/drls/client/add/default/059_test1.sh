echo "05 -test addclient - default"
