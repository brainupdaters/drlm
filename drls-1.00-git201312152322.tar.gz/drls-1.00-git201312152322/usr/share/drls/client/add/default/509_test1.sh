echo "50 -test addclient - default"
