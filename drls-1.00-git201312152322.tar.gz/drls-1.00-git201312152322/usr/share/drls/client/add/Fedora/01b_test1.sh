echo "01 -test addclient - default"
