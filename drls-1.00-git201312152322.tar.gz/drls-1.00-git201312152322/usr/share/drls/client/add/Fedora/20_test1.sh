echo "20 -test addclient - Fedora"
