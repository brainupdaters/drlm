echo "21 -test addclient - debian"
