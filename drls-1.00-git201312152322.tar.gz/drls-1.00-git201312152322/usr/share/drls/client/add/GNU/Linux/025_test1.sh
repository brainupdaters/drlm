echo "02 -test addclient - default"
