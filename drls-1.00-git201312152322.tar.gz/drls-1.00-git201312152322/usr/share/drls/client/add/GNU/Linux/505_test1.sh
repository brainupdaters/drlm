echo "50 -test addclient - debian"
