echo "01 -test addclient - debian"
