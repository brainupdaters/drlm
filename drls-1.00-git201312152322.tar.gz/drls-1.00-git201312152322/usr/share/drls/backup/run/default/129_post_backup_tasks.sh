#POST RUN BACKUP

        if [ $(stat -c %a ${PXEDIR}/${CLIENT}) != "755" ]
        then
                chmod 755 ${PXEDIR}/${CLIENT}
        fi

        if [ $(stat -c %a ${PXEDIR}/${CLIENT}/${CLIENT}.kernel) != "755") ]
        then
                chmod 755 ${PXEDIR}/${CLIENT}/${CLIENT}.kernel
        fi

