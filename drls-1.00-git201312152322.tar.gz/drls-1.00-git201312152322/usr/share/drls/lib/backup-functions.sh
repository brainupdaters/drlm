# file with default backup functions to implement.

function run_mkbackup_ssh_remote () {
  local CLI_ID=$1
#returns stdo of ssh  
}

function run_mkrescue_ssh_remote () {
  local CLI_ID=$1
#returns stdo of ssh
}
